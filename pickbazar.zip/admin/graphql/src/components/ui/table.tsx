import "rc-table/assets/index.css";
export { default as Table } from "rc-table";
